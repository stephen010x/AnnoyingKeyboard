#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <windows.h>
#include <time.h>

#include "extra_keydefs.h"

#define __FORCE_INLINE__ __attribute__((always_inline))
#define ABS(n) ({typeof(n) x = (n); (x > 0) ? x : -x;})
#define SIGN(n) ({typeof(n) x = (n); (x == 0) ? 0 : ((x > 0) ? 1 : -1);})
#define LENGTHOF(n) (sizeof(n)/sizeof(*(n)))

/*
Alright, here are some of the ideas for this one:
Has a chance to swap two keys by buffering them and then placing
Has a chance to replace a key with a nearby character.
Has a chance to never type the character at all.

nearby characters replacement are checked from a few lists
But stuff like never typing them at all can happen to any key
I think I might make the shift key more likely though.

What should the chances be for a typo? 1/20 characters?
And now how about the distribution of typos?
1 swap
1 replace
1 miss

And then missing a shift will be independant chance.
If you press the shift key, an 1/10 chance you miss it.
The weight of the space key is probably fine. Since it isn't in a list it should 
hopefully get passed to the other chances. 

I should also add a backspace thing where there is a chance you delete two instead of one characters.
*/

HHOOK g_hHook = NULL;

const DWORD keyrows[][13] = {
	{VK_1,       VK_2, VK_3, VK_4, VK_5, VK_6, VK_7, VK_8, VK_9, VK_0,                  VK_OEM_MINUS, VK_OEM_PLUS, VK_BACK},
	{VK_TAB,     VK_Q, VK_W, VK_E, VK_R, VK_T, VK_Y, VK_U, VK_I, VK_O,                  VK_P,         VK_OEM_4,    VK_OEM_6},
	{VK_CAPITAL, VK_A, VK_S, VK_D, VK_F, VK_G, VK_H, VK_J, VK_K, VK_L,                  VK_OEM_1,     VK_OEM_7,    VK_RETURN},
	{VK_LSHIFT,  VK_Z, VK_X, VK_C, VK_V, VK_B, VK_N, VK_M, VK_OEM_COMMA, VK_OEM_PERIOD, VK_OEM_2,     VK_RSHIFT,   VK_RETURN},
};

// inclusive, probably
__FORCE_INLINE__ int randint(int min, int max) {
    return min + rand() % (max - min + 1);
}

void popstruct_keypress(INPUT* pinput, DWORD keycode) {
	printf("<debug keycode %u>\n", keycode);
	pinput[0].type = INPUT_KEYBOARD;
	pinput[0].ki.wVk = keycode;
	pinput[1].type = INPUT_KEYBOARD;
	pinput[1].ki.wVk = keycode;
	pinput[1].ki.dwFlags = KEYEVENTF_KEYUP;
}

char VkCodeToChar(DWORD vkCode) {
    BYTE keyboardState[256];
    WORD charCode[2];
    if (!GetKeyboardState(keyboardState))
        return 0;
    int result = ToAscii(vkCode, MapVirtualKey(vkCode, MAPVK_VK_TO_VSC), keyboardState, charCode, 0);
    if (result == 1) {
        return (char)charCode[0];
    } else {
        return ' ';
    }
}

LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
	#if 0
	
	if (nCode >= 0 && wParam == WM_KEYDOWN) {
        PKBDLLHOOKSTRUCT pKey = (PKBDLLHOOKSTRUCT)lParam;
		DWORD keycode = pKey->vkCode;

        // Check if this is a key down event and if the key is 'A'
        if (randint(0, 4) == 0) {
            // Simulate pressing 'B' instead of 'A'
            INPUT input[2] = {0};
            input[0].type = INPUT_KEYBOARD;
            input[0].ki.wVk = keycode+1;  // Replace 'A' with 'B'
            input[1].type = INPUT_KEYBOARD;
            input[1].ki.wVk = keycode+1;
            input[1].ki.dwFlags = KEYEVENTF_KEYUP;

            SendInput(2, input, sizeof(INPUT));
            return 1;  // Tell Windows to block original 'A' key press
        }
    }

    return CallNextHookEx(g_hHook, nCode, wParam, lParam);
	
	#else
	if (nCode >= 0 && wParam == WM_KEYDOWN) {
        PKBDLLHOOKSTRUCT pKey = (PKBDLLHOOKSTRUCT)lParam;
		DWORD keycode = pKey->vkCode;
		static DWORD keybuff;
		//static int skipcount = 0;
		// is this a bug?
		//if (keycode == 0)
		//	return 1;
		printf("\nKey %c pressed (%u)\n", VkCodeToChar(keycode), keycode);
		/*if (skipcount > 0) {
			printf("Skipping typo\n");
			skipcount--;
			return 0;
		}*/
		// second stage of swap
		if (0 && keybuff != 0) {
			printf("swapping\n");
			INPUT input[4] = {0};
			popstruct_keypress(&input[0], keycode);
			popstruct_keypress(&input[2], keybuff);
			//skipcount = 2;
			UINT ok;
			if ((ok = SendInput(4, input, sizeof(INPUT))) != 4)
				printf("A - Failed SendInput (%u)\n", ok);
			keybuff = 0;
			printf("swap complete\n");
			return 1; // return 1 to block original key press
		}
		// chance typo generator
		int sbk = keycode == VK_SHIFT || keycode == VK_BACK || keycode == VK_RETURN || keycode == VK_TAB;
		if (randint(0, 4) == 0 || sbk && randint(0,9) == 0) {
			//INPUT input[2] = {0};
			//popstruct_keypress(input, VK_X);
			//skipcount = 1;
			//SendInput(2, input, sizeof(INPUT));
			printf("typo initiated\n");
			if (sbk)
				printf("sbk triggered\n");
			switch (0 * randint(keycode == VK_SPACE, 2)) {
			case 0: // replace
				printf("replace\n");
				for (int j = 0; j < LENGTHOF(keyrows); j++) 
				for (int i = 0; i < LENGTHOF(keyrows[0]); i++) {
					if (keycode != keyrows[j][i]) continue;
					int k = i + randint(0, 1) * 2 - 1;
					if (k < 0)
						k += 2;
					if (k >= LENGTHOF(keyrows[0]))
						k -= 2;
					INPUT input[2] = {0};
					popstruct_keypress(&input[0], keycode);
					SendInput(2, input, sizeof(INPUT));
					UINT ok;
					if ((ok = SendInput(2, input, sizeof(INPUT))) != 2)
						printf("B - Failed SendInput (%u)\n", ok);
					return 1;
				}
				break;
			case 1: // swap
				printf("swap\n");
				keybuff = pKey->scanCode;
				return 1;
			case 2: // miss
				printf("miss\n");
				return 1;
			}
			return 1; // return 1 to block original key press
		}
    }
    return CallNextHookEx(g_hHook, nCode, wParam, lParam);
	#endif
}

int main() {
	MSG msg;
	srand(time(NULL));
    g_hHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, NULL, 0);
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    UnhookWindowsHookEx(g_hHook);
    return 0;
}